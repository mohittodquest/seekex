<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <!-- Jquery CDN -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
        
        <!-- bootstrap cdn -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>  

        <!-- <link rel="stylesheet" type="text/css" href="/css/base.css"> -->
        <!-- <link rel="stylesheet" type="text/css" href="C:/Users/Mohit/Desktop/seekex/resources/css/base.css"> -->
        <style>
            *{
                text-align: center;
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }

            .head{
                background: #053964;
                color: #fff;
                padding: 0;
                margin: 0;
                width: 100%;
                height: 100px;
                display: flex;
                justify-content: center;
                align-items: center;
                font-size: 30px;
            }

            .head-1{
                background: #fc0;
                width: 35%;
                margin: auto;
                margin-top: -10px;
                margin-bottom: 30px;
                font-size: 25px;
                padding: 5px 20px;

            }

            .Designation{
                margin-bottom: 30px;
                font-weight: bold;
                font-size: 25px;
            }

            .rows{
                display:flex;
                justify-content: space-between; 
                width:75%;
                margin-left: auto;
                margin-right: auto;
                margin-top: 30px;
                align-items: center;
            }
            .table tbody tr{
                padding-bottom: 20px;

            }

            .table tbody tr td{
                border-left:1px solid #000;
                border-right:1px solid #000;
                padding-bottom: 20px;
            }

            input[type="number"]{
                width: 40px;
            }

            input[type="number"]::-webkit-outer-spin-button,
            input[type="number"]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
            }

            .rows tr{
                position: relative;
            }

            .rows span td:nth-child(2){
                position:absolute;top: 40%;left: 50%;transform: translate(-50%);
            }
        </style>
    </head>
    <body>
        <h3 class="head">Seekex Technologies Pvt. Ltd</h3>
        <h3 class="head-1">STAGE-2 ASSIGNMENT</h3>
        <h4 class="Designation">Designation: Senior Software Developer</h4>
        <!-- <h2>
            A B C D E
        </h2> -->
        <div class="rows">
            <span>
                <table border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td>
                            <img src="img/bucket.jpg" width="90" height="90"/>
                        </td>
                        <td>A</td>
                    </tr>
                    <tr>
                        <td><span id="buckA">0</span> cubic inches</td>
                    </tr>
                </table>
            </span>
            <span>
                <table border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td>
                            <img width="80" height="80" src="img/bucket.jpg" />
                        </td>
                        <td>B</td>
                    </tr>
                    <tr>
                        <td><span id="buckB">0</span> cubic inches </td>
                    </tr>
                </table>
            </span>
            <span>
                <table border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td>
                            <img width="70" height="70" src="img/bucket.jpg" />
                        </td>
                        <td>C</td>
                    </tr>
                    <tr>
                        <td><span id="buckC">0</span> cubic inches </td>
                    </tr>
                </table>
            </span>
    
            <span>
                <table border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td>
                            <img width="60" height="60" src="img/bucket.jpg" />
                        </td>
                        <td>D</td>
                    </tr>
                    <tr>
                        <td><span id="buckD">0</span> cubic inches </td>
                    </tr>
                </table>
            </span>
    
            <span>
                <table border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td>
                            <img width="50" height="50" src="img/bucket.jpg" />
                        </td>
                        <td>E</td>
                    </tr>
                    <tr>
                        <td><span id="buckE">0</span> cubic inches</td>
                    </tr>
                </table>
            </span>
          </div>

      <div class="rows">
        <span>
            <table border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td>
                        <img src="img/2.png" width="90" height="90"/>
                    </td>
                    <td>PINK</td>
                </tr>
                <tr>
                    <td><span id="ball_A">0</span> cubic inches</td>
                </tr>
            </table>
        </span>
        <span>
            <table border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td>
                        <img width="80" height="80" src="img/1.png" />
                    </td>
                    <td>RED</td>
                </tr>
                <tr>
                    <td><span id="ball_B">0</span> cubic inches </td>
                </tr>
            </table>
        </span>
        <span>
            <table border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td>
                        <img width="70" height="70" src="img/5.png" />
                    </td>
                    <td>BLUE</td>
                </tr>
                <tr>
                    <td><span id="ball_C">0</span> cubic inches </td>
                </tr>
            </table>
        </span>

        <span>
            <table border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td>
                        <img width="60" height="60" src="img/4.png" />
                    </td>
                    <td>ORANGE</td>
                </tr>
                <tr>
                    <td><span id="ball_D">0</span> cubic inches </td>
                </tr>
            </table>
        </span>

        <span>
            <table border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td>
                        <img width="50" height="50" src="img/3.png" />
                    </td>
                    <td>GREEN</td>
                </tr>
                <tr>
                    <td><span id="ball_E">0</span> cubic inches</td>
                </tr>
            </table>
        </span>
      </div>

        <p style="margin-bottom: 30px;">Diagram: 1</p>
        <p style="margin-bottom: 50px">Q:1 Design a system where inputs and the output will be as mentioned in the diagram below:</p>

        <table class="table" style="border-collapse: collapse; margin-left: auto;margin-right: auto;width: 80%;border:1px solid #000;" cellspacing="0">
            <tr>
                <td style="width: 530pt;" colspan="3" bgcolor="#000000">
                    <p style="text-align: center;color: #fff;">INPUTS</p>
                </td>
            </tr>
            <tr>
                <td style="width: 33%;">
                    <p>1. Add the volume of the buckets</p>
                </td>
                <td style="width: 33%;">
                    <p>2. Add the volume of the balls</p>
                </td>
                <td>
                    <p>3. Input the number of each colored ball to be placed inside the buckets:</p>
                </td>
            </tr>
            <tr>
                <td>
                    <p>A : <input type="number" id="bucketA"> cubic inches</p>
                </td>
                <td>
                    <p>A: Pink : <input type="number" id="ballA"> cubic inches</p>
                </td>
                <td>
                    <p>A: Pink :  <input type="number" id="sumA">  Ball</p>
                </td>
            </tr>
            <tr>
                <td>
                    <p style="padding-top: 1pt; ">B : <input type="number" id="bucketB"> cubic inches</p>
                </td>
                <td>
                    <p>B: Red : <input type="number" id="ballB"> cubic inches</p>
                </td>
                <td>
                    <p>B: Red :  <input type="number" id="sumB">  Ball</p>
                </td>
            </tr>
            <tr>
                <td>
                    <p style="padding-top: 1pt; ">C : <input type="number" id="bucketC"> cubic inches</p>
                </td>
                <td>
                    <p>C: Blue : <input type="number" id="ballC"> cubic inches</p>
                </td>
                <td>
                    <p>C: Blue :  <input type="number" id="sumC">  Ball</p>
                </td>
            </tr>
            <tr>
                <td>
                    <p>D : <input type="number" id="bucketD"> cubic inches</p>
                </td>
                <td>
                    <p>D: Orange : <input type="number" id="ballD"> cubic inches</p>
                </td>
                <td>
                    <p>D: Orange :  <input type="number" id="sumD">  Ball</p>
                </td>
            </tr>
            <tr>
                <td>
                    <p>E : <input type="number" id="bucketE"> cubic inches</p>
                </td>
                <td>
                    <p>E: Green : <input type="number" id="ballE"> cubic inches</p>
                </td>
                <td>
                    <p>E: Green :  <input type="number" id="sumE">  Ball</p>
                </td>
            </tr>
        </table>

        <h3>Empty volume = Bucket volume - Filled volume (Volume of balls) </h3>

        <h3>Total volume of Bucket = <span id="total_bucket"></span></h3>
        <h3>Total Volume of Ball = <span id="total_ball"></span></h3>
        <h3>Empty Volume = <span id="Empty_vol"></span></h3>
            
    </body>
    <script>
        $(document).ready(function(){
            var bucketA = null,bucketB = null,bucketC = null;bucketD = null,bucketE = null;
            var ballsA = null,ballsB = null,ballsC = null;ballsD = null,ballsE = null;
            
            $(document).on('keyup','#bucketA',function(){
                let bucA = $(this).val();
                bucketA = bucA;
                $("#buckA").text(bucA);
            });
            
            $(document).on('keyup','#bucketB',function(){
                let bucB = $(this).val();
                bucketB = bucB;
                $("#buckB").text(bucB);
            });
            $(document).on('keyup','#bucketC',function(){
                let bucC = $(this).val();
                bucketC = bucC;
                $("#buckC").text(bucC);
            });
            $(document).on('keyup','#bucketD',function(){
                let bucD = $(this).val();
                bucketD = bucD;
                $("#buckD").text(bucD);
            });
            $(document).on('keyup','#bucketE',function(){
                let bucE = $(this).val();
                bucketE = bucE;
                $("#buckE").text(bucE);
            });
            
            // ball section

            $(document).on('keyup','#ballA',function(){
                let ballA = $(this).val();
                ballsA = ballA;
                $("#ball_A").text(ballA);
            });
            $(document).on('keyup','#ballB',function(){
                let ballB = $(this).val();
                ballsB = ballB;
                $("#ball_B").text(ballB);
            });
            $(document).on('keyup','#ballC',function(){
                let ballC = $(this).val();
                ballsC = ballC;
                $("#ball_C").text(ballC);
            });
            $(document).on('keyup','#ballD',function(){
                let ballD = $(this).val();
                ballsD = ballD;
                $("#ball_D").text(ballD);
            });
            $(document).on('keyup','#ballE',function(){
                let ballE = $(this).val();
                ballsE = ballE;
                $("#ball_E").text(ballE);
            });

            // Sum section 
            var Total_bucket = null;
            var Total_ball = null;
            var empty_volume = null;
            var sumA = null,sumB = null,sumC = null,sumD = null,sumE = null;
            var aocA = null,aocB = null,aocC = null,aocD = null,aocE = null;
            var emptyA = null,emptyB = null,emptyC = null,emptyD = null,emptyE = null;

            // A PART
            $(document).on('keyup','#sumA',function(){
                // sumA = $(this).val()*$("#ball_A").val();
                let value = $(this).val();
                let ball = $("#ballA").val();
                let cuberoot = ball*3/4*1/3.14;
                cuberoot = Math.cbrt(cuberoot);
                // Area of circle
                let AOC = 3.14*cuberoot;
                sumA = value*ball;
                aocA = AOC*value;
                emptyA = aocA-sumA;
                calculate();
            });

            // B PART
            $(document).on('keyup','#sumB',function(){
                // sumA = $(this).val()*$("#ball_A").val();
                let value = $(this).val();
                let ball = $("#ballB").val();
                let cuberoot = ball*3/4*1/3.14;
                cuberoot = Math.cbrt(cuberoot);
                // Area of circle
                let AOC = 3.14*cuberoot;
                
                sumB = value*ball;
                aocB = AOC*value;
                emptyB = aocB-sumB;
                calculate();
            });
            
            // C PART
            $(document).on('keyup','#sumC',function(){
                // sumA = $(this).val()*$("#ball_A").val();
                let value = $(this).val();
                let ball = $("#ballC").val();
                let cuberoot = ball*3/4*1/3.14;
                cuberoot = Math.cbrt(cuberoot);
                // Area of circle
                let AOC = 3.14*cuberoot;
                
                sumC = value*ball;
                aocC = AOC*value;
                emptyC = aocC-sumC;
                calculate();
            });

            // D PART
            $(document).on('keyup','#sumD',function(){
                // sumA = $(this).val()*$("#ball_A").val();
                let value = $(this).val();
                let ball = $("#ballD").val();
                let cuberoot = ball*3/4*1/3.14;
                cuberoot = Math.cbrt(cuberoot);
                // Area of circle
                let AOC = 3.14*cuberoot;
                sumD = value*ball;
                aocD = AOC*value;
                emptyD = aocD-sumD;
                calculate();
            });
            $(document).on('keyup','#sumE',function(){
                // sumA = $(this).val()*$("#ball_A").val();
                let value = $(this).val();
                let ball = $("#ballE").val();
                let cuberoot = ball*3/4*1/3.14;
                cuberoot = Math.cbrt(cuberoot);
                // Area of circle
                let AOC = 3.14*cuberoot;
                
                sumE = value*ball;
                aocE = AOC*value;
                emptyE = aocE-sumE;
                calculate();
            });
            var Total_Empty = null;
            function calculate(){
                Total_bucket = bucketA+bucketB+bucketC+bucketD+bucketE;
                // Total_ball = ballsA+ballsB+ballsC+ballsD+ballsE;
                Total_ball = aocA+aocB+aocC+aocD+aocE;
                Total_Empty = emptyA+emptyB+emptyC+emptyD+emptyE;
                // alert(Total_Empty);
                // if(Total_Empty >= ballsA || Total_Empty >= ballsB || Total_Empty >= ballsC || Total_Empty >= ballsD || Total_Empty >= ballsE){

                // }

                if(bucketA <= Total_ball){
                    Total_ball = Total_ball-bucketA;
                    if(bucketB <= Total_ball){
                        Total_ball = Total_ball-bucketB;
                        if(bucketC <= Total_ball){
                            Total_ball = Total_ball-bucketC;
                            if(bucketD <= Total_ball){
                                Total_ball = Total_ball-bucketD;
                                if(bucketE <= Total_ball){
                                    Total_ball = Total_ball-bucketE;
                                }else{
                                    empty_volume = Total_bucket-Total_ball;
                                }
                            }else {
                                empty_volume = Total_bucket-Total_ball;
                            }
                        }else{
                            empty_volume = Total_bucket-Total_ball;
                        }
                    }else{
                        empty_volume = Total_bucket-Total_ball;
                    }
                }else{
                    if(bucketA > Total_ball){
                        empty_volume = Total_bucket-Total_ball;
                        empty_volume=Total_Empty+empty_volume;
                    } else if(Total_ball != 0 || Total_ball != NULL){
                        if(Total_Empty>Total_ball){
                            empty_volume = Total_Empty-Total_ball;
                        }
                        
                    }else{
                        empty_volume = 'All Balls are not filled some balls are left';
                    }
                    
                }
                $('total_bucket').text(Total_bucket);
                $('total_ball').text(Total_ball);
                $('Empty_vol').text(empty_volume);
                alert(empty_volume);
                
            }

        });
    </script>
</html>
